const fs = require('fs')
const chalk = require('chalk')

global.pairingNumber = '6283847024615'
global.owner = '6283847024615@s.whatsapp.net'
global.namabot = 'GALIRUS-OFFICIAL'
global.namaowner = 'GALIRUS-OFFICIAL.'
global.packname = '© 𝓚𝓲𝓵𝓵𝓾𝓪 𝓜𝓾𝓵𝓽𝓲𝓭𝓮𝓿𝓲𝓬𝓮 𝓿3'
global.website = 'https://rezae.vercel.app'
global.author = 'MD'
global.idkomunitas = '120363200092279741@g.us'
global.thumbnail = "https://telegra.ph/file/40ef07e7416a20accc262.jpg"
global.thumbnailBroadcast = 'https://telegra.ph/file/40ef07e7416a20accc262.jpg'
global.thumbnailOwner = 'https://telegra.ph/file/40ef07e7416a20accc262.jpg'
global.linkgc = 'https://chat.whatsapp.com/BG9t2hLFAznAIEjInulPQu'
global.qris = 'https://i.ibb.co/x6fp5zf/IMG-20231228-WA0172.jpg'

global.limitawal = 10
global.balanceawal = 10000

global.autoSimi = false
global.onlyGroup = true
global.autoRead = true
global.welcome = true
global.notifikasiCmd = true
global.antilinkGroup = false
global.antiBot = true
global.antilinkNoKick = false

global.mess = {
    done: '*D o n e ✅*',
    admin: '*Fitur ini hanya untuk admin grup!*',
    linkvalid: '*Link tautan tidak valid!*', 
    botadmin: '*Fitur ini dapat digunakan ketika bot menjadi admin grup!*',
    owner: '*Fitur ini untuk owner bot!*',
    premium: '*Fitur ini hanya untuk user premium!*\n\nKetik *.buypremium* untuk membeli akses user premium',
    group: '*Fitur ini hanya untuk dalam grup!*',
    private: '*Fitur ini hanya untuk dalam private chat!*',
    wait: '*Memproses tunggu sebentar . . .*',
    error: '*Error terjadi kesalahan!*', 
    limit: `\n*Limit* kamu sudah habis!\nketik *.buylimit* untuk membeli limit`
}

let file = require.resolve(__filename)
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(chalk.redBright(`Update'${__filename}'`))
delete require.cache[file]
require(file)
})